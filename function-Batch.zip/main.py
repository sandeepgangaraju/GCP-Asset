'''
This simple a Cloud Function responsible for:
- Loading data using schemas
- Loading data from different data file formats 
'''

import json
import logging
import os
import traceback
from datetime import datetime
import io
import re

from google.cloud import bigquery
from google.cloud import storage



PROJECT_ID = os.getenv('marker-study-pilot')
BQ_DATASET = 'eu_data'
CS = storage.Client()
BQ = bigquery.Client()
job_config = bigquery.LoadJobConfig()

"""
This is our Cloud Function:
"""
def stream_gcs(data, context):
     bucketname = data['bucket'] 
     filename = data['name']     
     timeCreated = data['timeCreated']
     tableName = 'nb_stream_test_js'
     
     try:
          # check if table exists, otherwise create:
          _check_if_table_exists(tableName)

          # Check source file data format. Depending on that we'll use different methods:
          _load_table_from_json(data['bucket'], data['name'], tableName)
                    
          
     except Exception:
          _handle_error()


def _check_if_table_exists(tableName):
     # get table_id reference
     table_id = BQ.dataset(BQ_DATASET).table(tableName)

     # check if table exists, otherwise create
     try:
          BQ.get_table(table_id)
     except Exception:
          logging.error('%s doesnt exist!' % (tableName))


def _load_table_from_json(bucket_name, file_name, tableName):
     blob = CS.get_bucket(bucket_name).blob(file_name)
     body = json.loads(blob.download_as_string())
     table_id = BQ.dataset(BQ_DATASET).table(tableName)

     job_config.source_format = bigquery.SourceFormat.NEWLINE_DELIMITED_JSON,
     job_config.write_disposition = 'WRITE_APPEND'
     #lb = len(body)
     #for i in range(lb):
     #   body[i]['response_time'] = body[i]['Responses'][0]['Miscellaneous']['TodaysDateTime']

     errors = BQ.insert_rows(BQ.get_table(table_id), rows=body)
  
    
     if errors != []:
          raise BigQueryError(errors)
     else:
          print("Job finished.")


def _handle_error():
     message = 'Error streaming file. Cause: %s' % (traceback.format_exc())
     print(message)

class BigQueryError(Exception):
     '''Exception raised whenever a BigQuery error happened''' 

     def __init__(self, errors):
          super().__init__(self._format(errors))
          self.errors = errors

     def _format(self, errors):
          err = []
          for error in errors:
               err.extend(error['errors'])
          return json.dumps(err)