from google.cloud import bigquery
from google.cloud import storage
import base64, json, sys, os

def pubsub_to_bigq(event, context):
   pubsub_message = base64.b64decode(event['data']).decode('utf-8')
   data = json.loads(pubsub_message)
   response_time = data['Responses'][0]['Miscellaneous']['TodaysDateTime']
   data['Response_todaysdatetime'] = response_time
   d = convert(data)
   #print(d)
   to_bigquery(os.environ['dataset'], os.environ['table'], d)   


def convert(data):
      if isinstance(data, bool):
          return str(data).lower()
      if isinstance(data, (list, tuple)):
          return [convert(item) for item in data]
      if isinstance(data, dict):
         return {convert(key):convert(value) for key, value in data.items()}
      return data
   

def to_bigquery(dataset, table, document):
   
   try:
      bigquery_client = bigquery.Client()
      dataset_ref = bigquery_client.dataset(dataset)
      table_ref = dataset_ref.table(table)
      table = bigquery_client.get_table(table_ref)

      errors = bigquery_client.insert_rows(table, [document])
      if errors != [] :
         print(errors, file=sys.stderr)
         storage_client = storage.Client()
         transaction_id = document['TransactionId']
         blob_name = transaction_id + '.json'
         bucket = storage_client.get_bucket('source_stream_sg')
         blob = bucket.blob(blob_name)

         blob.upload_from_string(
            data=json.dumps(document),
            content_type='application/json'
         )
   except:
      print("Error in processing JSON")
   finally:
      print("Processing Complete")